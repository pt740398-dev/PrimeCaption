# Prime Captions — Android source project

- App: Prime Captions
- Application ID: `com.primecaptions.editor`
- Version: `0.1.0`
- Min Android: 8.0 (API 26)
- Build: Gradle 8.9 / JDK 17 / Android SDK 35

## Implemented in this source
- Video selection using Android document picker
- Audio-track extraction and decode using Android MediaExtractor / MediaCodec
- On-device Vosk speech recognition
- First-run model download and extraction for Hindi or English
- Word-level timestamps from recognizer output
- Normal and Pro word-by-word caption preview modes
- Word list with timestamps
- SRT and TXT export
- GitHub Actions workflow to build and upload a debug APK

## Important limitations
- Hindi and English models are separate; Hinglish code-switching can be inaccurate.
- The first model download needs internet and device storage (model is cached afterward).
- This version exports timed SRT/TXT. It does not yet burn captions into an MP4 video.
- No cloud API key is required. Audio recognition runs locally after model download.

## Build using GitHub Actions
1. Create a GitHub repository named `PrimeCaptions`.
2. Upload the *contents* of this ZIP to the repository root (not the ZIP itself).
3. Open Actions → `Prime Captions APK Build` → Run workflow.
4. When green, open the workflow run → Artifacts → `Prime-Captions-debug-apk`.

The workflow uses Gradle 8.9 and JDK 17. It uploads the APK as a GitHub Actions artifact.
