package com.primecaptions.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val Background = Color(0xFF090B12)
private val SurfaceDark = Color(0xFF151927)
private val Purple = Color(0xFF9B72FF)
private val SecondaryText = Color(0xFF9AA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeCaptionsApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrimeCaptionsApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("No video selected") }
    var words by remember { mutableStateOf(listOf<CaptionWord>()) }
    var language by remember { mutableStateOf("Hindi") }
    var style by remember { mutableStateOf("PRO") }
    var status by remember { mutableStateOf("Video choose karke Auto Caption dabao") }
    var busy by remember { mutableStateOf(false) }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var fontSize by remember { mutableFloatStateOf(26f) }
    var allText by remember { mutableStateOf("") }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected video"
            words = emptyList()
            allText = ""
            status = "Video ready • Auto Caption dabao"
        }
    }
    val saveSrt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(toSrt(words)) }
                        ?: error("File save nahi hui")
                }
            }.onSuccess { status = "SRT export complete" }
                .onFailure { status = "Export error: ${it.message}" }
        }
    }
    val saveTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(words.joinToString(" ") { w -> w.text }) }
                        ?: error("File save nahi hui")
                }
            }.onSuccess { status = "TXT export complete" }
                .onFailure { status = "Export error: ${it.message}" }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Background, surface = SurfaceDark)) {
        Scaffold(containerColor = Background) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Purple, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text("P", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("PRIME CAPTIONS", fontWeight = FontWeight.Black, fontSize = 19.sp, letterSpacing = 1.sp)
                        Text("AUTO SUBTITLE STUDIO", color = SecondaryText, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Text("v0.1.0", color = SecondaryText, fontSize = 11.sp)
                }

                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VideoFile, null, tint = Purple)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("SOURCE VIDEO", color = SecondaryText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(videoName, maxLines = 1, fontSize = 13.sp)
                            }
                        }
                        OutlinedButton(onClick = { pickVideo.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text("Choose video")
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF20263A)), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("CAPTION PREVIEW", color = SecondaryText, fontSize = 10.sp, letterSpacing = 1.4.sp)
                        Spacer(Modifier.height(12.dp))
                        val preview = when {
                            words.isEmpty() -> "YOUR CAPTION HERE"
                            style == "NORMAL" -> words.take(7).joinToString(" ") { it.text }
                            else -> words.getOrNull(selectedIndex)?.text?.uppercase() ?: words.first().text.uppercase()
                        }
                        Text(
                            preview.uppercase(),
                            color = Color.White,
                            fontSize = (fontSize / 1.25f).sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = if (style == "PRO") 1.sp else 0.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(if (style == "PRO") "WORD-BY-WORD STYLE" else "STANDARD SUBTITLE", color = Purple, fontSize = 9.sp)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = language == "Hindi", onClick = { language = "Hindi" }, label = { Text("Hindi") })
                    FilterChip(selected = language == "English", onClick = { language = "English" }, label = { Text("English") })
                    Spacer(Modifier.weight(1f))
                    FilterChip(selected = style == "NORMAL", onClick = { style = "NORMAL" }, label = { Text("Normal") })
                    FilterChip(selected = style == "PRO", onClick = { style = "PRO" }, label = { Text("Pro") })
                }

                Button(
                    onClick = {
                        val source = videoUri
                        if (source == null) status = "Pehle video choose karo"
                        else {
                            busy = true
                            status = "Starting…"
                            scope.launch {
                                try {
                                    val result = withContext(Dispatchers.IO) {
                                        CaptionEngine.transcribe(context, source, language) { message ->
                                            scope.launch { status = message }
                                        }
                                    }
                                    words = result
                                    selectedIndex = 0
                                    allText = result.joinToString(" ") { it.text }
                                    status = "${result.size} words detected • Captions ready"
                                } catch (e: Exception) {
                                    status = "Error: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                } finally { busy = false }
                            }
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(19.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (busy) "Generating captions…" else "✨  AUTO CAPTION")
                }

                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Purple)
                Text(status, color = SecondaryText, fontSize = 11.sp)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("CAPTION WORDS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${words.size} words", color = SecondaryText, fontSize = 11.sp)
                }
                if (words.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Generated words yahan dikhenge", color = SecondaryText, fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        itemsIndexed(words) { index, word ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(if (index == selectedIndex) Color(0xFF30234B) else SurfaceDark, RoundedCornerShape(9.dp))
                                    .clickable { selectedIndex = index }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(String.format(Locale.US, "%.2fs", word.start), color = Purple, fontSize = 10.sp, modifier = Modifier.width(52.dp))
                                Text(word.text, modifier = Modifier.weight(1f), fontWeight = if (index == selectedIndex) FontWeight.Bold else FontWeight.Normal)
                                Text(String.format(Locale.US, "%.2fs", word.end - word.start), color = SecondaryText, fontSize = 10.sp)
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { if (words.isNotEmpty()) saveSrt.launch("prime-captions.srt") },
                        enabled = words.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.Subtitles, null); Spacer(Modifier.width(5.dp)); Text("Export SRT") }
                    OutlinedButton(
                        onClick = { if (words.isNotEmpty()) saveTxt.launch("prime-captions.txt") },
                        enabled = words.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.TextSnippet, null); Spacer(Modifier.width(5.dp)); Text("Export TXT") }
                }
                Text("Offline speech model • First use needs model download • Mixed Hinglish accuracy may vary", color = Color(0xFF667087), fontSize = 9.sp)
            }
        }
    }
}

private fun toSrt(words: List<CaptionWord>): String {
    return words.chunked(5).mapIndexed { index, chunk ->
        val start = chunk.first().start
        val end = chunk.last().end
        "${index + 1}\n${srtTime(start)} --> ${srtTime(end)}\n${chunk.joinToString(" ") { it.text }}\n"
    }.joinToString("\n")
}

private fun srtTime(seconds: Double): String {
    val ms = (seconds * 1000).toLong().coerceAtLeast(0)
    val hours = ms / 3600000
    val minutes = (ms % 3600000) / 60000
    val secs = (ms % 60000) / 1000
    val millis = ms % 1000
    return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, secs, millis)
}
