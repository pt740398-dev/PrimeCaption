# Prime Captions — Android project

- Application ID: `com.primecaptions.editor`
- Version: `0.2.0`
- Minimum Android: 8.0 (API 26)
- Build: Gradle 8.9 / JDK 17 / Android SDK 35

## Features in this editor build

- App splash/loading screen
- Video selection and in-app playback preview with play/pause
- Hindi, Hinglish and English recognition choices
- Vosk offline speech recognition after first model download
- Word-level timestamps
- Live caption preview synced to video playback
- Classic, Pro and Karaoke caption styles
- Sans, Serif and Mono font choices
- White, Yellow and Cyan caption colours
- Bottom and Center caption positions
- Adjustable caption text size
- SRT and TXT export
- MP4 export using AndroidX Media3 Transformer with timed captions burned into the video

## Language note

Hindi uses the Vosk Hindi model. English uses the Vosk English model. Hinglish currently uses the English model; mixed Hindi-English recognition and Roman Hindi transcription can be imperfect. Recognition quality depends on the audio and model.

## Build with GitHub Actions

1. Upload this ZIP file to the repository root using the exact name `Prime_Captions_Android_Project_0_4_EDITOR.zip`.
2. Replace `.github/workflows/android-apk.yml` in the repository with the workflow included in this project (or upload the workflow file from this archive to that path).
3. Delete older project ZIPs so the workflow cannot select an old version.
4. Open Actions → Prime Captions APK Build → Run workflow.
5. Download the `Prime-Captions-APK` artifact after a successful build.

MP4 export re-encodes the video and may take time depending on video length, resolution, available storage and device capabilities.
