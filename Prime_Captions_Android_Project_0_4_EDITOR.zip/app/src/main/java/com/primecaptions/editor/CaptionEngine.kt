package com.primecaptions.editor

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.math.max
import kotlin.math.min

data class CaptionWord(val start: Double, val end: Double, val text: String)

object CaptionEngine {
    private const val TAG = "PrimeCaptions"
    private const val SAMPLE_RATE = 16000

    fun transcribe(
        context: Context,
        uri: Uri,
        language: String,
        onProgress: (String) -> Unit
    ): List<CaptionWord> {
        val modelDir = ensureModel(context, language, onProgress)
        onProgress("Video audio decode ho raha hai…")
        val pcm = decodeAudio(context, uri)
        if (pcm.isEmpty()) error("Video mein readable audio track nahi mila.")
        onProgress("Speech recognition chal raha hai…")
        val model = Model(modelDir.absolutePath)
        val recognizer = Recognizer(model, SAMPLE_RATE.toFloat())
        recognizer.setWords(true)
        val words = mutableListOf<CaptionWord>()
        try {
            val chunkBytes = 8192
            var offset = 0
            while (offset < pcm.size) {
                val count = min(chunkBytes, pcm.size - offset)
                val chunk = pcm.copyOfRange(offset, offset + count)
                if (recognizer.acceptWaveForm(chunk, count)) {
                    parseWords(recognizer.result, words)
                }
                offset += count
            }
            parseWords(recognizer.finalResult, words)
        } finally {
            recognizer.close()
            model.close()
        }
        if (words.isEmpty()) error("Speech detect nahi hui. Clear voice/audio ke saath try karo.")
        return words
    }

    private fun ensureModel(context: Context, language: String, onProgress: (String) -> Unit): File {
        val (folder, modelUrl) = if (language == "Hindi") {
            "vosk-model-small-hi-0.22" to "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
        } else {
            "vosk-model-small-en-us-0.15" to "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
        }
        val base = File(context.filesDir, "speech-models")
        val model = File(base, folder)
        if (File(model, "conf/model.conf").exists() || File(model, "am").exists()) return model
        base.mkdirs()
        val zip = File(base, "$folder.zip")
        onProgress("$language speech model download ho raha hai (first time)…")
        val connection = (URL(modelUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 60000
            instanceFollowRedirects = true
        }
        try {
            connection.inputStream.use { input ->
                FileOutputStream(zip).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        total += n
                        if (total % (2L * 1024 * 1024) < buffer.size) {
                            onProgress("Model download: ${total / (1024 * 1024)} MB")
                        }
                    }
                }
            }
        } finally { connection.disconnect() }
        onProgress("Speech model extract ho raha hai…")
        ZipInputStream(BufferedInputStream(zip.inputStream())).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val out = File(base, entry.name).canonicalFile
                require(out.path.startsWith(base.canonicalPath + File.separator)) { "Invalid model archive" }
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        zip.delete()
        if (!model.exists()) error("Speech model extract nahi hua.")
        return model
    }

    private fun decodeAudio(context: Context, uri: Uri): ByteArray {
        val extractor = MediaExtractor()
        context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            extractor.setDataSource(pfd.fileDescriptor)
        } ?: error("Video file open nahi hui.")
        try {
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    track = i; format = f; break
                }
            }
            if (track < 0 || format == null) error("Audio track nahi mila.")
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: error("Unsupported audio")
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()
            val info = MediaCodec.BufferInfo()
            val output = java.io.ByteArrayOutputStream()
            var inputDone = false
            var outputDone = false
            var sourceRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var sourceChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex)!!
                        val size = extractor.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val outputIndex = decoder.dequeueOutputBuffer(info, 10000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outFormat = decoder.outputFormat
                        sourceRate = outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        sourceChannels = outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outputIndex >= 0) {
                        val buffer = decoder.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val raw = ByteArray(info.size)
                            buffer.get(raw)
                            appendResampledMono16(raw, sourceChannels, sourceRate, output)
                        }
                        decoder.releaseOutputBuffer(outputIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                }
            }
            decoder.stop()
            decoder.release()
            return output.toByteArray()
        } finally { extractor.release() }
    }

    private fun appendResampledMono16(raw: ByteArray, channels: Int, rate: Int, out: java.io.ByteArrayOutputStream) {
        if (raw.size < 2 || channels < 1 || rate < 1) return
        val frames = raw.size / (2 * channels)
        if (frames <= 0) return
        val mono = ShortArray(frames)
        var p = 0
        for (i in 0 until frames) {
            var sum = 0
            repeat(channels) {
                val lo = raw[p++].toInt() and 0xff
                val hi = raw[p++].toInt()
                sum += ((hi shl 8) or lo).toShort().toInt()
            }
            mono[i] = (sum / channels).toShort()
        }
        val targetFrames = (frames.toLong() * SAMPLE_RATE / rate).toInt()
        val bytes = ByteArray(targetFrames * 2)
        for (i in 0 until targetFrames) {
            val sourcePos = i.toDouble() * rate / SAMPLE_RATE
            val a = min(sourcePos.toInt(), frames - 1)
            val b = min(a + 1, frames - 1)
            val fraction = sourcePos - a
            val sample = (mono[a] * (1.0 - fraction) + mono[b] * fraction).toInt().coerceIn(-32768, 32767)
            bytes[i * 2] = (sample and 0xff).toByte()
            bytes[i * 2 + 1] = ((sample shr 8) and 0xff).toByte()
        }
        out.write(bytes)
    }

    private fun parseWords(json: String, output: MutableList<CaptionWord>) {
        val array = JSONObject(json).optJSONArray("result") ?: return
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val word = item.optString("word").trim()
            if (word.isNotEmpty()) output.add(
                CaptionWord(item.optDouble("start"), max(item.optDouble("end"), item.optDouble("start") + 0.12), word)
            )
        }
    }
}
