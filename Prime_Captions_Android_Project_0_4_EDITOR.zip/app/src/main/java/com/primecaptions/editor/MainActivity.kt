package com.primecaptions.editor

import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

private val Background = Color(0xFF090B12)
private val SurfaceDark = Color(0xFF151927)
private val Purple = Color(0xFF9B72FF)
private val SecondaryText = Color(0xFF9AA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeCaptionsApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrimeCaptionsApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showSplash by remember { mutableStateOf(true) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("No video selected") }
    var words by remember { mutableStateOf(listOf<CaptionWord>()) }
    var language by remember { mutableStateOf("Hindi") }
    var style by remember { mutableStateOf("Karaoke") }
    var font by remember { mutableStateOf("Sans") }
    var captionColor by remember { mutableStateOf("White") }
    var position by remember { mutableStateOf("Bottom") }
    var fontSize by remember { mutableFloatStateOf(28f) }
    var status by remember { mutableStateOf("Choose a video to get started") }
    var busy by remember { mutableStateOf(false) }
    var exportBusy by remember { mutableStateOf(false) }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var playbackPosition by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var videoView by remember { mutableStateOf<VideoView?>(null) }
    var pendingMp4 by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(Unit) {
        delay(900)
        showSplash = false
    }

    LaunchedEffect(videoUri) {
        videoView?.stopPlayback()
        playbackPosition = 0L
        isPlaying = false
        words = emptyList()
        selectedIndex = 0
    }

    LaunchedEffect(videoView, videoUri) {
        val player = videoView
        val uri = videoUri
        if (player != null && uri != null) {
            player.setVideoURI(uri)
            player.setOnPreparedListener { it.isLooping = false; status = "Video ready • Play karke preview dekho" }
            player.setOnCompletionListener { isPlaying = false }
        }
    }

    LaunchedEffect(videoView, isPlaying) {
        while (isPlaying) {
            videoView?.let { playbackPosition = it.currentPosition.toLong() }
            delay(100)
        }
    }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected video"
            status = "Video selected • Generate captions"
        }
    }

    val saveSrt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(toSrt(words)) }
                        ?: error("Could not create SRT file")
                }
            }.onSuccess { status = "SRT exported successfully" }
                .onFailure { status = "SRT export failed: ${it.message}" }
        }
    }

    val saveTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { out -> out.write(words.joinToString(" ") { it.text }) }
                        ?: error("Could not create TXT file")
                }
            }.onSuccess { status = "TXT exported successfully" }
                .onFailure { status = "TXT export failed: ${it.message}" }
        }
    }

    val saveMp4 = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        val file = pendingMp4
        if (uri != null && file != null && file.exists()) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                        ?: error("Could not save MP4")
                }
            }.onSuccess { status = "MP4 exported successfully • Captions burned in" }
                .onFailure { status = "MP4 save failed: ${it.message}" }
                .also { file.delete(); pendingMp4 = null }
        } else {
            file?.delete()
            pendingMp4 = null
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Background, surface = SurfaceDark)) {
        if (showSplash) {
            Box(Modifier.fillMaxSize().background(Background), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(76.dp).background(Purple, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                        Text("P", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("PRIME CAPTIONS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("AUTO SUBTITLE STUDIO", color = SecondaryText, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(24.dp))
                    CircularProgressIndicator(color = Purple, strokeWidth = 2.dp)
                }
            }
        } else {
            Scaffold(containerColor = Background) { padding ->
                Column(
                    Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(13.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Purple, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                            Text("P", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text("PRIME CAPTIONS", fontWeight = FontWeight.Black, fontSize = 19.sp, letterSpacing = 1.sp)
                            Text("AUTO SUBTITLE STUDIO", color = SecondaryText, fontSize = 9.sp, letterSpacing = 1.5.sp)
                        }
                        Text("v0.2.0", color = SecondaryText, fontSize = 11.sp)
                    }

                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VideoFile, null, tint = Purple)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("SOURCE VIDEO", color = SecondaryText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(videoName, maxLines = 1, fontSize = 13.sp)
                                }
                            }
                            OutlinedButton(onClick = { pickVideo.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text("Choose video")
                            }
                        }
                    }

                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF20263A)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("VIDEO PREVIEW", color = SecondaryText, fontSize = 10.sp, letterSpacing = 1.4.sp)
                            Box(Modifier.fillMaxWidth().height(230.dp).background(Color.Black, RoundedCornerShape(12.dp))) {
                                if (videoUri == null) {
                                    Text("Choose a video to preview", color = SecondaryText, modifier = Modifier.align(Alignment.Center))
                                } else {
                                    AndroidView(
                                        factory = { ctx -> VideoView(ctx).also { videoView = it } },
                                        modifier = Modifier.fillMaxSize(),
                                        update = { view -> if (videoView !== view) videoView = view }
                                    )
                                    val active = activeCaption(words, playbackPosition / 1000.0, style)
                                    if (active.isNotBlank()) {
                                        Text(
                                            active,
                                            modifier = Modifier.align(if (position == "Center") Alignment.Center else Alignment.BottomCenter)
                                                .padding(horizontal = 12.dp, vertical = if (position == "Center") 0.dp else 22.dp)
                                                .background(if (style == "Classic") Color(0x99000000) else Color.Transparent, RoundedCornerShape(6.dp))
                                                .padding(horizontal = 8.dp, vertical = 5.dp),
                                            color = previewColor(captionColor),
                                            fontSize = (fontSize * 0.62f).sp,
                                            fontWeight = if (style == "Classic") FontWeight.Medium else FontWeight.Black,
                                            fontFamily = previewFont(font),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(
                                    onClick = {
                                        val player = videoView
                                        if (player != null) {
                                            if (player.isPlaying) { player.pause(); isPlaying = false }
                                            else { player.start(); isPlaying = true }
                                        }
                                    }, enabled = videoUri != null
                                ) {
                                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                                    Text(if (isPlaying) "Pause" else "Play")
                                }
                                Text(String.format(Locale.US, "%.1fs", playbackPosition / 1000.0), color = SecondaryText, fontSize = 11.sp)
                                Spacer(Modifier.weight(1f))
                                Text("Preview updates with playback", color = SecondaryText, fontSize = 9.sp)
                            }
                        }
                    }

                    SectionTitle("1. SPEECH LANGUAGE")
                    ChoiceRow(listOf("Hindi", "Hinglish", "English"), language) { language = it }
                    if (language == "Hinglish") Text("Hinglish uses the English speech model; mixed Hindi-English accuracy can vary.", color = SecondaryText, fontSize = 10.sp)

                    SectionTitle("2. CAPTION STYLE")
                    ChoiceRow(listOf("Classic", "Pro", "Karaoke"), style) { style = it }
                    SectionTitle("3. FONT")
                    ChoiceRow(listOf("Sans", "Serif", "Mono"), font) { font = it }
                    SectionTitle("4. TEXT COLOUR")
                    ChoiceRow(listOf("White", "Yellow", "Cyan"), captionColor) { captionColor = it }
                    SectionTitle("5. CAPTION POSITION")
                    ChoiceRow(listOf("Bottom", "Center"), position) { position = it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Font size", color = SecondaryText, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${fontSize.toInt()} sp", color = Color.White, fontSize = 12.sp)
                    }
                    Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 18f..48f)

                    Button(
                        onClick = {
                            val source = videoUri
                            if (source == null) status = "Pehle video choose karo"
                            else {
                                busy = true
                                status = "Preparing speech recognition…"
                                scope.launch {
                                    try {
                                        val result = withContext(Dispatchers.IO) {
                                            CaptionEngine.transcribe(context, source, language) { message -> scope.launch { status = message } }
                                        }
                                        words = result
                                        selectedIndex = 0
                                        status = "${result.size} words detected • Preview ready"
                                    } catch (e: Exception) {
                                        status = "Caption error: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                    } finally { busy = false }
                                }
                            }
                        },
                        enabled = !busy && !exportBusy,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (busy) "Generating captions…" else "GENERATE AUTO CAPTIONS")
                    }

                    if (busy || exportBusy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Purple)
                    Text(status, color = SecondaryText, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("CAPTION WORDS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${words.size} words", color = SecondaryText, fontSize = 11.sp)
                    }
                    words.take(100).forEachIndexed { index, word ->
                        Row(
                            Modifier.fillMaxWidth().background(if (index == selectedIndex) Color(0xFF30234B) else SurfaceDark, RoundedCornerShape(9.dp)).padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(String.format(Locale.US, "%.2fs", word.start), color = Purple, fontSize = 10.sp, modifier = Modifier.width(54.dp))
                            Text(word.text, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Text(String.format(Locale.US, "%.2fs", word.end - word.start), color = SecondaryText, fontSize = 10.sp)
                        }
                    }
                    if (words.size > 100) Text("Showing first 100 words here; all words remain included in exports.", color = SecondaryText, fontSize = 10.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { if (words.isNotEmpty()) saveSrt.launch("prime-captions.srt") }, enabled = words.isNotEmpty() && !exportBusy, modifier = Modifier.weight(1f)) { Text("Export SRT") }
                        OutlinedButton(onClick = { if (words.isNotEmpty()) saveTxt.launch("prime-captions.txt") }, enabled = words.isNotEmpty() && !exportBusy, modifier = Modifier.weight(1f)) { Text("Export TXT") }
                    }
                    Button(
                        onClick = {
                            val source = videoUri
                            if (source == null || words.isEmpty()) status = "Pehle video select karke captions generate karo"
                            else {
                                exportBusy = true
                                status = "MP4 export starting…"
                                scope.launch {
                                    try {
                                        val file = withContext(Dispatchers.Main) {
                                            VideoExporter.export(context, source, words, style, font, captionColor, position, fontSize) { msg -> status = msg }
                                        }
                                        pendingMp4 = file
                                        saveMp4.launch("prime-captions-export.mp4")
                                    } catch (e: Exception) {
                                        status = "MP4 export failed: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                    } finally { exportBusy = false }
                                }
                            }
                        },
                        enabled = words.isNotEmpty() && !busy && !exportBusy,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Text(if (exportBusy) "Exporting MP4…" else "EXPORT VIDEO (MP4)")
                    }
                    Text("Offline speech recognition after model download • MP4 export burns captions into the video. Export time depends on video length and phone speed.", color = Color(0xFF667087), fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(value: String) {
    Text(value, color = SecondaryText, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
}

@Composable
private fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
        options.forEach { option ->
            FilterChip(selected = selected == option, onClick = { onSelect(option) }, label = { Text(option, fontSize = 11.sp) })
        }
    }
}

private fun activeCaption(words: List<CaptionWord>, seconds: Double, style: String): String {
    if (words.isEmpty()) return ""
    val index = words.indexOfFirst { seconds >= it.start && seconds <= it.end }
    if (index < 0) return ""
    return when (style) {
        "Classic" -> words.drop((index / 5) * 5).take(5).joinToString(" ") { it.text }
        "Pro" -> words.drop((index / 3) * 3).take(3).joinToString(" ") { it.text }
        else -> words[index].text.uppercase(Locale.getDefault())
    }
}

private fun previewFont(font: String): FontFamily = when (font) {
    "Serif" -> FontFamily.Serif
    "Mono" -> FontFamily.Monospace
    else -> FontFamily.SansSerif
}

private fun previewColor(name: String): Color = when (name) {
    "Yellow" -> Color(0xFFFFE45E)
    "Cyan" -> Color(0xFF6DEBFF)
    else -> Color.White
}

private fun toSrt(words: List<CaptionWord>): String {
    return words.chunked(5).mapIndexed { index, chunk ->
        "${index + 1}\n${srtTime(chunk.first().start)} --> ${srtTime(chunk.last().end)}\n${chunk.joinToString(" ") { it.text }}\n"
    }.joinToString("\n")
}

private fun srtTime(seconds: Double): String {
    val ms = (seconds * 1000).toLong().coerceAtLeast(0)
    return String.format(Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, (ms % 3600000) / 60000, (ms % 60000) / 1000, ms % 1000)
}
