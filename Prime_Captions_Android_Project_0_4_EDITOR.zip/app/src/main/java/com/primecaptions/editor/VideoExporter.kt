package com.primecaptions.editor

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.RelativeSizeSpan
import android.text.style.TypefaceSpan
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@OptIn(UnstableApi::class)
object VideoExporter {
    suspend fun export(
        context: Context,
        source: Uri,
        words: List<CaptionWord>,
        style: String,
        font: String,
        color: String,
        position: String,
        fontSize: Float,
        onProgress: (String) -> Unit
    ): File = suspendCancellableCoroutine { continuation ->
        val output = File(context.cacheDir, "prime-captions-${System.currentTimeMillis()}.mp4")
        val overlay = TimedCaptionOverlay(words, style, font, color, position, fontSize)
        val videoEffects = listOf(OverlayEffect(listOf(overlay)))
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(source))
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    if (continuation.isActive) {
                        if (output.exists() && output.length() > 0L) continuation.resume(output)
                        else continuation.resumeWithException(IllegalStateException("MP4 output file was empty"))
                    }
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    output.delete()
                    if (continuation.isActive) continuation.resumeWithException(exportException)
                }
            })
            .build()
        continuation.invokeOnCancellation {
            runCatching { transformer.cancel() }
            output.delete()
        }
        try {
            onProgress("Rendering captions into MP4…")
            transformer.start(edited, output.absolutePath)
        } catch (error: Exception) {
            output.delete()
            if (continuation.isActive) continuation.resumeWithException(error)
        }
    }
}

@OptIn(UnstableApi::class)
private class TimedCaptionOverlay(
    private val words: List<CaptionWord>,
    private val style: String,
    private val font: String,
    private val color: String,
    private val position: String,
    private val fontSize: Float
) : TextOverlay() {
    private val settings = StaticOverlaySettings.Builder()
        .setOverlayFrameAnchor(0f, 0f)
        .setBackgroundFrameAnchor(0f, if (position == "Center") 0f else -0.78f)
        .build()

    override fun getText(presentationTimeUs: Long): SpannableString {
        val seconds = presentationTimeUs / 1_000_000.0
        val index = words.indexOfFirst { seconds >= it.start && seconds <= it.end }
        val text = if (index < 0) "" else when (style) {
            "Classic" -> words.drop((index / 5) * 5).take(5).joinToString(" ") { it.text }
            "Pro" -> words.drop((index / 3) * 3).take(3).joinToString(" ") { it.text }
            else -> words[index].text.uppercase()
        }
        return SpannableString(text).apply {
            if (isNotEmpty()) {
                val textColor = when (color) {
                    "Yellow" -> android.graphics.Color.rgb(255, 228, 94)
                    "Cyan" -> android.graphics.Color.rgb(109, 235, 255)
                    else -> android.graphics.Color.WHITE
                }
                setSpan(ForegroundColorSpan(textColor), 0, length, 0)
                setSpan(StyleSpan(Typeface.BOLD), 0, length, 0)
                val family = when (font) {
                    "Serif" -> "serif"
                    "Mono" -> "monospace"
                    else -> "sans-serif"
                }
                setSpan(TypefaceSpan(family), 0, length, 0)
                setSpan(RelativeSizeSpan((fontSize / 32f).coerceIn(0.55f, 1.6f)), 0, length, 0)
                if (style == "Classic") setSpan(BackgroundColorSpan(0x99000000.toInt()), 0, length, 0)
            }
        }
    }

    override fun getOverlaySettings(presentationTimeUs: Long) = settings
}
